# To run


```
javac TicTacToe.java
java TicTacToe
```

# A sample run

```


```